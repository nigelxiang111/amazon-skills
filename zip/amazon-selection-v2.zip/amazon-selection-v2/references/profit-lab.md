# SKILL: amazon-profit-lab
亚马逊利润实验室技能。核算产品利润可行性，输出三情景P&L表、盈亏平衡分析、资本效率报告和利润层SWOT。

**触发关键词**：帮我算利润、核算成本、这个品能不能做、算一下ROI、利润分析、成本核算、值不值得做（财务角度）

---

## 前置：确认信息（缺失则询问）
- 产品 ASIN 或售价
- 产品尺寸/重量（计算FBA费和头程运费必须）
- 目标站点（默认US）
- 月目标销量（默认200件）

---

## 第一阶段：数据采集

【缓存检查】以下数据若已在对话中存在则跳过调用。

**【卖家精灵优先】ASIN基础数据（有ASIN时）：**
- `mcp__maijiajingl__asin_details` → 售价/类目/尺寸重量/BSR/月销量
- **不可用 →** `mcp__sorftime__product_detail`

**【卖家精灵优先】关键词/CPC（并行）：**
- `mcp__maijiajingl__keyword_mining`（产品核心词）→ CPC参考（用于ACoS估算）
- **不可用 →** `mcp__sorftime__keyword_detail`（核心词）

**【卖家精灵独有】ACoS/市场广告数据：**
- `mcp__maijiajingl__market_statistics`（对应类目）→ 查看广告竞争强度，辅助估算ACoS
  - 有数据 → 结合 CPC 综合估算合理 ACoS
  - 无数据 / 不可用 → 使用类目均值（服装/鞋包15%、电子8%、通用25%）

**【sorftime 独有，不与卖家精灵重复】采购成本：**
- `mcp__sorftime__ali1688_similar_product` → 采购价（取第1页，排除最高/最低，取25%~75%分位）

---

## 第二阶段：P&L计算

使用 `scripts/pnl.py`（工具A）：
1. 将采集数据填入脚本变量（price / cogs_cny / weight_kg / fba_fee / commission_rate / acos_base / monthly_target）
2. 写入 `/tmp/pnl.py` 并执行 `python3 /tmp/pnl.py`
3. 将输出的三情景结果、盈亏平衡、启动资金估算纳入报告

**Python 不可用时**：按脚本中的注释公式逐项手算，结果完全等价。

**ACoS填入规则（优先级）：**
1. 卖家精灵 market_statistics 提供的广告竞争强度 + keyword_mining CPC → 综合估算
2. 上述无数据 → sorftime keyword_detail CPC 估算
3. 均无数据 → 用类目均值，脚本注释中标注「估算值」

---

## 第三阶段：利润层SWOT + 评分

- S：毛利率>25% / ROI>50% / 供应链货源稳定 / 资金周转快
- W：广告依赖高(ACoS>30%) / 库存资金压力 / 头程成本占比高
- O：1688降价谈判空间 / 差异化提价5~15% / 转化率提升降ACoS
- T：FBA费用年度上涨 / 汇率波动 / 原材料涨价

使用 `scripts/scorer.py`（工具B），重点强化资本效率维度（capital权重↑）。

---

## 第四阶段：输出格式

```
💰 利润实验室：[产品/ASIN]（[站点]）
📊 三情景P&L（来自pnl.py输出）
⚖️ 盈亏平衡：ACoS上限X% | 保本售价$X
💼 总启动资金$X,XXX | 月净利$XXX | 回本第X月
📐 8维度评分（scorer.py输出）综合：X.X/10
🔲 利润层SWOT
🎯 可行性判断：[✅利润可行/⚡边际产品需优化/❌当前不可行]
   核心问题 + 最关键优化动作（供应链降本/定价调整/ACoS优化目标）
📌 数据来源：售价[卖家精灵/sorftime] | CPC[卖家精灵/sorftime] | ACoS[卖家精灵估算/类目均值] | 1688[sorftime]
```
